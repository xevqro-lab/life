LifeFlow для Vercel

1. Загрузите содержимое этой папки в новый проект Vercel.
2. В Vercel откройте Settings -> Environment Variables.
3. Добавьте переменную:
   OPENROUTER_API_KEY = ваш ключ OpenRouter
4. Отметьте Production, Preview и Development (можно все среды).
5. Выполните Redeploy после добавления переменной.

Важно: не вставляйте API-ключ в index.html и не отправляйте его другим людям.
